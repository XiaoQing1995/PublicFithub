<template>
    <a class="nav-link collapsed " href="#" data-bs-toggle="collapse"
								data-bs-target="#collapseLayoutsActivity" aria-expanded="false"
								aria-controls="collapseLayouts">
								<div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
								活動管理
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
							</a>
							<div class="collapse" id="collapseLayoutsActivity" aria-labelledby="headingOne"
								data-bs-parent="#sidenavAccordion">
								<nav class="sb-sidenav-menu-nested nav">
									<a class="nav-link" href="activity">全部活動</a>
									<a class="nav-link" href="insertActivity">新增活動</a>
								</nav>
							</div>
</template>
